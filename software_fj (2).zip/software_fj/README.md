# Software FJ – Sistema de Gestión de Clientes, Servicios y Reservas

Proyecto POO en Python 3.10+ (UNAD – Programación 213023, Fase 4). Sin base de datos: todo en objetos y listas; el único archivo es el log.

## Ejecución
    python main.py
El log se genera en `logs/software_fj.log`.

## Estructura
| Archivo | Contenido |
|---|---|
| `entidad.py` | Clase abstracta `Entidad` |
| `cliente.py` | `Cliente` con encapsulación y validaciones |
| `servicios.py` | `Servicio` (abstracta) + `ReservaSala`, `AlquilerEquipo`, `Asesoria` |
| `reserva.py` | `Reserva` (confirmar, cancelar, procesar) |
| `excepciones.py` | Excepciones personalizadas |
| `logger.py` | Configuración del log |
| `gestor.py` | Listas internas y registro seguro de objetos |
| `main.py` | Simulación de 15 operaciones |

## Conceptos aplicados
- **Abstracción:** `Entidad` y `Servicio` (`ABC` + `@abstractmethod`).
- **Herencia y polimorfismo:** los 3 servicios sobrescriben `calcular_costo_base`, `validar_parametros` y `describir`.
- **Encapsulación:** atributos privados con `@property` y validación en los setters.
- **Sobrecarga:** Python no la tiene de forma nativa; se simula con parámetros opcionales en `calcular_costo(horas, impuesto=None, descuento=0.0)`.
- **Excepciones:** personalizadas, `try/except`, `try/except/else`, `try/except/finally` y encadenamiento con `raise ... from ...`.
- **Logs:** cada error y evento relevante queda registrado.

## Reparto sugerido (5 integrantes)
1. `excepciones.py` + `logger.py`
2. `entidad.py` + `cliente.py`
3. `servicios.py`
4. `reserva.py`
5. `gestor.py` + `main.py` + README
